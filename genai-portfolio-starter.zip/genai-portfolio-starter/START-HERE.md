# Your first GitHub portfolio

This pack contains two independent project folders, each ready to become a separate GitHub repository. They are educational starters developed with AI assistance. No account or repository has been created by downloading this pack.

## GitHub in everyday language
GitHub stores project files online and lets other people inspect them. A repository (repo) is one project folder with a history of changes. Git is the software that tracks those changes. A README is the project's explanation, normally displayed on its front page. A commit is a named checkpoint of changes. Push uploads local commits; pull brings remote changes to your laptop. A branch is a separate line of work. A pull request proposes merging a branch and makes the changes reviewable.

GitHub normally hosts code; uploading a Python app does not automatically run or deploy it. A GitHub repository is also different from a GitHub Project, which is a planning board. You want repositories for these code projects.

## What is included
| Repository name | What it demonstrates |
| --- | --- |
| document-qa-assistant | Chunking, ranked retrieval, source evidence, optional local LLM generation |
| llm-answer-evaluator | Reference-based checks, retrieval recall, limitations of lexical metrics |

Start with the Q&A README and run its no-key example. Then run the evaluator. Understand both before presenting them as portfolio work. These are first versions to develop further, not evidence of five years of production delivery.

## First upload through the website
1. Sign in to your personal account at https://github.com/ (create an account if necessary).
2. Open https://github.com/new and use your personal account as Owner.
3. Name the first repository `document-qa-assistant`. Description: `Document retrieval with source evidence and optional local LLM answers using synthetic data.`
4. Start with Private while learning. You can later make a reviewed portfolio repository Public. Leave automatic README, .gitignore, and license initialization off because your folder already has its README and ignore file. Choose Create repository.
5. On the empty repository page, choose the link to upload an existing file. In a repository with files, use Add file > Upload files.
6. Extract this ZIP on your laptop. Upload the CONTENTS of `document-qa-assistant` into the repository root, preserving `data`, `examples`, and other subfolders. Do not upload the ZIP itself or the entire portfolio parent folder. Browser file selectors sometimes hide `.gitignore`; enable hidden files if necessary, or create that file using Add file > Create new file and copy its contents.
7. Use the commit message `Add initial document Q&A learning project` and choose Commit changes.
8. Confirm README.md and app.py appear at the top level and read the README on GitHub.
9. Repeat for `llm-answer-evaluator`, using its contents and the description `Transparent evaluation of saved answers and retrieved sources with synthetic examples.`

Official instructions: [Create a repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/quickstart-for-repositories), [Upload files](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository).

## Your first update
Open README.md on GitHub, choose Edit, add a short note about what you learned from running the project, and commit with `Document first local run`. This creates a real, understandable contribution. For code changes, download or clone the project, edit and test it locally, then publish the changes. We can introduce Git commands once this first workflow is comfortable.

## Profile wording to review
Suggested short bio: `GenAI Engineer at Virtusa | 5+ years of experience | Building and learning through independent AI projects.`
Only add skills you can explain. Describe client work only when disclosure is permitted; these sample projects do not contain or represent Google internal work. Do not upload employer code, prompts, documents, client names in data, credentials, or confidential designs. No license is selected automatically; select a license deliberately before offering reuse permissions.

## Next development steps
Run both projects; explain one function at a time; add five original synthetic questions; record failures; improve retrieval and compare results; then add a third project around structured extraction or agent workflows. Make small commits that reflect actual work, and retain the AI-assistance disclosure. Never invent deployment metrics, customers, project history, or production claims.
